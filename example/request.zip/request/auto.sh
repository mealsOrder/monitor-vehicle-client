#! /bin/bash
make clean
qmake request.pro
make
